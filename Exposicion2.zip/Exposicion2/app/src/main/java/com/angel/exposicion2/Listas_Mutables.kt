package com.angel.exposicion2

fun main() {

    //------------------LISTAS MUTABLES----------//
    /*  val nombres = mutableListOf("Ana", "Luis", "Carlos")

    nombres.add("Maria")          // Agregamos a maria en cola
    nombres.remove("Luis")       // Quitar, Aqui eliminamos por completo a Luis
    nombres[0] = "Andrea"        // Modificar, Aqui Ana se reemplaza por Andre en la posicion 0
    nombres.add("Jorge")

    println(nombres.size) // [Andrea, Carlos, María]

  */
    //------------------MAPS O DICCIONARIOS-------------//
    /*
    val edades = mutableMapOf(
        "Ana" to 25,
        "Luis" to 30,
        "Carlos" to 28
    )
    println(edades)
    edades["Ana"] = 21 // Modificamos la edad
    println("Edad Ana nuevo: "+edades["Ana"])
    println("Edad Luis viejo: "+edades["Luis"])

    edades["Jhair"]=28
    println(edades)

    edades.remove("Luis")
    println(edades)
*/

    //--------Transformaciones-------//
//Maps
    /*   val numeros = listOf(1,2,3,4)
    val cuadrados = numeros.map{it*it}
    println("NUMEROS: "+numeros)
    println("CUADRADOS: "+cuadrados) */
//ZIPS
    /*  val nombres = listOf("Ana", "Luis", "Carlos")
    val edades = listOf(25, 30, 28)
    val nombres_edades = nombres.zip(edades)

    println(nombres)
    println(edades)
    println(nombres_edades) */

//FLATTEN
/*
    val listas = listOf(
        listOf(1, 2),
        listOf(3, 4),
        listOf(5)
    )

    val todo_junto = listas.flatten()
    println(listas)
    println(listas[0])
    println(listas[1])
    println(listas[2])
    println(todo_junto)
*/
}

